"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { SitePageFrame } from "@/app/_components/site/site-page-frame";
import { useRevealOnView } from "@/hooks/use-reveal-on-view";
import { templateCategories, templates } from "@/data/templates";
import { getTemplateHref, siteRoutes } from "@/lib/site-config";
import { siteChromeDots, siteTones } from "@/lib/site-tones";

type TemplateItem = (typeof templates)[number];
type TemplateCategory = (typeof templateCategories)[number];

const templateBrandTone = siteTones.brand;
const templateTonePrimary = siteTones.brand;
const templateToneStructural = siteTones.client;
const templateToneLifted = siteTones.data;
const templateToneOperational = siteTones.gateway;
const templateToneCommerce = siteTones.services;

const templateCategoryTones: Record<
  TemplateCategory,
  { accent: string; border: string; surface: string }
> = {
  SaaS: templateTonePrimary,
  Dashboards: templateToneStructural,
  "Internal tools": templateToneOperational,
  "AI assistants": templateToneLifted,
  Marketplaces: templateToneCommerce,
  "Booking platforms": templateToneCommerce,
  "E-commerce": templateToneCommerce,
  "Mobile apps": templateToneLifted,
};

// Group templates by category
function getTemplatesByCategory() {
  const grouped: Record<TemplateCategory, TemplateItem[]> = {} as Record<TemplateCategory, TemplateItem[]>;
  for (const category of templateCategories) {
    grouped[category] = templates.filter((t) => t.category === category);
  }
  return grouped;
}

// ============================================================================
// TEMPLATE PREVIEW VISUAL
// ============================================================================

function TemplatePreviewVisual() {
  const [activeTemplate, setActiveTemplate] = useState(0);
  const { ref: previewRef, isVisible } = useRevealOnView<HTMLDivElement>({ threshold: 0.3 });

  const templatePreviews = [
    {
      name: "Dashboard",
      icon: "grid",
      tone: templateToneStructural,
    },
    {
      name: "Portal",
      icon: "layout",
      tone: templateTonePrimary,
    },
    {
      name: "Platform",
      icon: "layers",
      tone: templateToneLifted,
    },
  ] as const;

  useEffect(() => {
    if (!isVisible) return;
    const interval = setInterval(() => {
      setActiveTemplate((prev) => (prev + 1) % templatePreviews.length);
    }, 2500);
    return () => clearInterval(interval);
  }, [isVisible, templatePreviews.length]);

  const activeTone = templatePreviews[activeTemplate].tone;

  return (
    <div
      ref={previewRef}
      className={`rounded-2xl border border-border bg-card overflow-hidden transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
    >
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-secondary/30">
        <div className="flex gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: siteChromeDots.red }} />
          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: siteChromeDots.amber }} />
          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: siteChromeDots.green }} />
        </div>
        <span className="inline-flex items-center gap-2 text-xs font-mono text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: activeTone.accent }} />
          template.preview
        </span>
      </div>

      {/* Template browser */}
      <div className="p-4">
        {/* Tabs */}
        <div className="flex gap-1 mb-4 p-1 bg-secondary/50 rounded-lg">
          {templatePreviews.map((template, index) => (
            <button
              key={template.name}
              onClick={() => setActiveTemplate(index)}
              className={`flex-1 rounded-md border border-transparent px-3 py-2 text-xs font-medium transition-all duration-300 ${index === activeTemplate ? "shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
              style={
                index === activeTemplate
                  ? {
                      backgroundColor: template.tone.surface,
                      borderColor: template.tone.border,
                      color: template.tone.accent,
                    }
                  : undefined
              }
            >
              <span className="inline-flex items-center gap-1.5">
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ backgroundColor: template.tone.accent, opacity: index === activeTemplate ? 1 : 0.45 }}
                />
                {template.name}
              </span>
            </button>
          ))}
        </div>

        {/* Preview window */}
        <div className="relative rounded-xl border border-border bg-background overflow-hidden aspect-[4/3]">
          {/* Browser chrome mini */}
          <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-secondary/30">
          <div className="flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: siteChromeDots.red }} />
              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: siteChromeDots.amber }} />
              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: siteChromeDots.green }} />
          </div>
            <div className="flex-1 mx-2 h-4 bg-secondary rounded-md" />
          </div>

          {/* Template layout preview */}
          <div className="p-3 h-full">
            {/* Dashboard preview */}
            {activeTemplate === 0 && (
              <div className={`space-y-2 transition-all duration-500 ${isVisible ? "opacity-100" : "opacity-0"}`}>
                <div className="flex justify-between items-center">
                  <div className="w-12 h-2 bg-foreground/80 rounded" />
                  <div className="flex gap-1">
                    {[1, 2, 3].map(i => <div key={i} className="w-6 h-1.5 bg-secondary rounded" />)}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3">
                  {[1, 2, 3].map(i => (
                    <div
                      key={i}
                      className="aspect-square rounded-lg border p-2"
                      style={
                        i === 1
                          ? { borderColor: templatePreviews[0].tone.border, backgroundColor: templatePreviews[0].tone.surface }
                          : undefined
                      }
                    >
                      <div
                        className="mb-1 h-1 w-full rounded"
                        style={i === 1 ? { backgroundColor: templatePreviews[0].tone.accent } : undefined}
                      />
                      <div className="w-2/3 h-3 bg-foreground/10 rounded" />
                    </div>
                  ))}
                </div>
                <div className="h-12 bg-secondary rounded-lg mt-2" />
              </div>
            )}

            {/* Portal preview */}
            {activeTemplate === 1 && (
              <div className={`flex gap-2 h-full transition-all duration-500 ${isVisible ? "opacity-100" : "opacity-0"}`}>
                <div className="w-16 bg-secondary rounded-lg p-2 space-y-2">
                  {[1, 2, 3, 4].map(i => (
                    <div
                      key={i}
                      className={`h-2 rounded ${i === 1 ? "" : "bg-foreground/20"}`}
                      style={i === 1 ? { backgroundColor: templatePreviews[1].tone.accent } : undefined}
                    />
                  ))}
                </div>
                <div className="flex-1 space-y-2">
                  <div className="h-6 rounded-lg border" style={{ borderColor: templatePreviews[1].tone.border, backgroundColor: templatePreviews[1].tone.surface }} />
                  <div className="grid grid-cols-2 gap-2 flex-1">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="aspect-video bg-secondary rounded-lg" />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Platform preview */}
            {activeTemplate === 2 && (
              <div className={`space-y-2 h-full transition-all duration-500 ${isVisible ? "opacity-100" : "opacity-0"}`}>
                <div className="flex items-center justify-between">
                  <div className="w-8 h-2 bg-foreground rounded" />
                  <div className="flex gap-2">
                    <div className="w-16 h-5 bg-secondary rounded-full" />
                    <div className="w-5 h-5 rounded-full" style={{ backgroundColor: templatePreviews[2].tone.accent }} />
                  </div>
                </div>
                <div className="mt-3 h-16 rounded-lg border" style={{ borderColor: templatePreviews[2].tone.border, backgroundColor: templatePreviews[2].tone.surface }} />
                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3].map(i => (
                    <div
                      key={i}
                      className="h-10 rounded-lg"
                      style={i === 2 ? { backgroundColor: templatePreviews[2].tone.surface, border: `1px solid ${templatePreviews[2].tone.border}` } : undefined}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Template info */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
          <span className="text-xs text-muted-foreground">
            {templatePreviews[activeTemplate].name} template
          </span>
          <span
            className="inline-flex items-center gap-1.5 rounded-full border px-2 py-1"
            style={{
              borderColor: activeTone.border,
              backgroundColor: activeTone.surface,
              color: activeTone.accent,
            }}
          >
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: activeTone.accent }} />
            <span className="text-[10px]">Ready to customize</span>
          </span>
        </div>
      </div>
    </div>
  );
}

export default function TemplatesPage() {
  const templatesByCategory = getTemplatesByCategory();
  const categoriesWithTemplates = templateCategories.filter(
    (cat) => templatesByCategory[cat]?.length > 0
  );

  const { ref: headerRef, isVisible: headerVisible } = useRevealOnView<HTMLDivElement>({ threshold: 0.1 });

  return (
    <SitePageFrame>
      {/* Hero */}
      <section ref={headerRef} className="site-hero-section">
        <div className="site-shell">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <span 
                className={`inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6 transition-all duration-700 ${headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
              >
                <span className="w-8 h-px" style={{ backgroundColor: templateBrandTone.accent }} />
                Templates
              </span>
              <h1 
                className={`text-4xl lg:text-5xl font-display tracking-tight mb-6 transition-all duration-700 ${headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                style={{ transitionDelay: "100ms" }}
              >
                Choose a starting point
              </h1>
              <p 
                className={`text-base lg:text-lg text-muted-foreground leading-relaxed mb-8 transition-all duration-700 ${headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                style={{ transitionDelay: "200ms" }}
              >
                Structured baselines to accelerate scoping and delivery. 
                Not themes, not boxed products, just credible starting points.
              </p>
              <div 
                className={`flex flex-wrap gap-4 transition-all duration-700 ${headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                style={{ transitionDelay: "300ms" }}
              >
                <Link
                  href={siteRoutes.maxwell}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-transform hover:scale-[1.02] active:scale-[0.98] hover:bg-primary/90"
                >
                  Start with Maxwell
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href={siteRoutes.services}
                  className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-medium transition-colors hover:bg-secondary"
                >
                  View services
                </Link>
              </div>
            </div>
            
            {/* Template Preview Visual */}
            <div className="hidden lg:block">
              <TemplatePreviewVisual />
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="site-section bg-secondary/30">
        <div className="site-shell">
          <div className="flex items-center justify-between mb-8">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground">
              <span className="w-8 h-px" style={{ backgroundColor: templateBrandTone.accent }} />
              Categories
            </span>
            <span className="text-sm" style={{ color: templateBrandTone.accent }}>
              {categoriesWithTemplates.length} categories
            </span>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {categoriesWithTemplates.map((category, index) => (
              <CategoryCard 
                key={category} 
                category={category} 
                templates={templatesByCategory[category]} 
                index={index}
              />
            ))}
          </div>
        </div>
      </section>

      {/* All Templates */}
      <section className="site-section">
        <div className="site-shell">
          <div className="flex items-center justify-between mb-8">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground">
              <span className="w-8 h-px" style={{ backgroundColor: templateBrandTone.accent }} />
              All templates
            </span>
            <span className="text-sm" style={{ color: templateBrandTone.accent }}>
              {templates.length} templates
            </span>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {templates.map((template, index) => (
              <TemplateCard key={template.slug} template={template} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="site-section-lg bg-foreground text-background">
        <div className="site-shell text-center">
          <h2 className="text-2xl lg:text-3xl font-display tracking-tight mb-4">
            Not sure which template fits?
          </h2>
          <p className="text-background/70 mb-8 max-w-md mx-auto">
            Let Maxwell help you find the right starting point.
          </p>
          <Link
            href={siteRoutes.maxwell}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-transform hover:scale-[1.02] active:scale-[0.98] hover:bg-primary/90"
          >
            Start with Maxwell
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </SitePageFrame>
  );
}

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

function CategoryCard({ 
  category, 
  templates: categoryTemplates, 
  index 
}: { 
  category: TemplateCategory; 
  templates: TemplateItem[]; 
  index: number;
}) {
  const [isHovered, setIsHovered] = useState(false);
  const { ref: cardRef, isVisible } = useRevealOnView<HTMLAnchorElement>({ threshold: 0.2 });
  const firstTemplate = categoryTemplates[0];
  const tone = templateCategoryTones[category];

  return (
    <Link
      ref={cardRef}
      href={`#${category.toLowerCase().replace(/\s+/g, "-")}`}
      className={`group relative overflow-hidden rounded-xl border border-border bg-card transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
      style={{
        transitionDelay: `${index * 60}ms`,
        borderColor: isHovered ? tone.border : undefined,
        boxShadow: isHovered ? `0 18px 36px -30px ${tone.border}` : undefined,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="aspect-[4/3] relative overflow-hidden bg-secondary/40">
        {firstTemplate?.image && (
          <Image
            src={firstTemplate.image}
            alt={category}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-card/90 to-transparent" />
        <div className="absolute right-4 top-4">
          <span
            className="inline-flex items-center gap-1.5 rounded-full border px-2 py-1 text-[10px] font-mono"
            style={{
              borderColor: tone.border,
              backgroundColor: isHovered ? tone.surface : "rgba(255, 255, 255, 0.88)",
              color: tone.accent,
            }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: tone.accent }} />
            {categoryTemplates.length}
          </span>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="flex items-center gap-2 text-sm font-medium text-foreground">
          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: tone.accent }} />
          {category}
        </h3>
        <p className="mt-0.5 text-xs text-muted-foreground" style={isHovered ? { color: tone.accent } : undefined}>
          {categoryTemplates.length} template{categoryTemplates.length !== 1 ? "s" : ""}
        </p>
      </div>
    </Link>
  );
}

function TemplateCard({ 
  template, 
  index 
}: { 
  template: TemplateItem; 
  index: number;
}) {
  const [isHovered, setIsHovered] = useState(false);
  const { ref: cardRef, isVisible } = useRevealOnView<HTMLAnchorElement>({ threshold: 0.1 });
  const tone = templateCategoryTones[template.category];

  return (
    <Link
      ref={cardRef}
      href={getTemplateHref(template.slug)}
      className={`group relative overflow-hidden rounded-xl border border-border bg-card transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
      style={{
        transitionDelay: `${(index % 6) * 60}ms`,
        borderColor: isHovered ? tone.border : undefined,
        boxShadow: isHovered ? `0 18px 36px -30px ${tone.border}` : undefined,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="aspect-video relative overflow-hidden bg-secondary/40">
        {template.image && (
          <Image
            src={template.image}
            alt={template.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <span
            className="rounded border px-2 py-0.5 text-[10px] font-mono uppercase tracking-wider"
            style={{
              borderColor: tone.border,
              backgroundColor: tone.surface,
              color: tone.accent,
            }}
          >
            {template.category}
          </span>
        </div>
        <h3 className="text-sm font-medium text-foreground mb-1 group-hover:text-foreground/80 transition-colors">
          {template.name}
        </h3>
        <p className="text-xs text-muted-foreground line-clamp-2">
          {template.summary}
        </p>
        <div className="mt-3 pt-3 border-t border-border">
          <span
            className="inline-flex items-center gap-1 text-xs font-medium transition-all group-hover:gap-2"
            style={isHovered ? { color: tone.accent } : undefined}
          >
            View template
            <ArrowRight className="w-3 h-3" />
          </span>
        </div>
      </div>
    </Link>
  );
}
